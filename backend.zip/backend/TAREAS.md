# Lista de tareas LingoKids World (Actualizada)

1. Crear estructura básica del proyecto backend - Backend ✅
2. Crear estructura básica del proyecto frontend - Frontend ✅
3. Instalar dependencias backend - Backend ✅
4. Instalar dependencias frontend - Frontend ✅
5. Creación de base de datos - Otros ✅
6. Crear modelo personalizado de usuario con roles - Backend ✅
7. Crear modelo PerfilInfantil asociado a un usuario padre - Otros ✅
8. Crear vista y endpoint para registrar usuarios con rol padre o niño - Backend ✅
9. Crear tabla de progreso (Progreso) - Frontend ✅
10. Crear modelo Cuento - Otros ✅
11. Crear endpoint REST para devolver cuentos por idioma - Backend ✅
12. Crear modelo Juego y TipoJuego - Backend ✅
13. Diseñar estructura visual del dashboard en Figma - Diseño ✅
14. Implementar dashboard inicial con acceso a cuentos, juegos y progreso - Frontend ✅
15. Crear endpoint que devuelva juegos filtrados por tipo y nivel - Backend ✅
16. Implementar primer juego (Matching Words) - Frontend ✅
17. Crear modelo Avatar y Recompensa - Backend ✅
18. Diseñar componente de biblioteca de cuentos en Figma - Diseño ✅
19. Implementar formulario de registro y login en React - Otros ✅
20. Guardar y reutilizar JWT en frontend - Frontend ✅
21. Crear componente de biblioteca de cuentos y carga desde API - Frontend ✅
22. Crear selector de juegos con dificultad adaptable - Frontend ✅
23. Crear lógica para otorgar puntos y logros tras completar cuentos o juegos - Backend ✅
24. Crear pantalla de configuración parental - Frontend ✅
25. Diseñar estructura de navegación de la app - Diseño ✅
26. Implementar navegación principal con React Router - Frontend ✅
27. Diseñar interfaz responsive para tablet y móvil - Diseño ✅
28. Crear layout general de la app - Frontend ✅
29. Crear componente de bienvenida personalizada - Frontend ✅
30. Crear pantalla de error 404 y feedback visual - Frontend ✅
31. Pruebas funcionales completas - QA ⏳
32. Pruebas unitarias en backend - Backend ⏳
33. Despliegue de backend en Railway - DevOps ⏳
34. Despliegue de frontend en Vercel - DevOps ⏳
35. Validación en dispositivos reales - QA ⏳
36. Recoger feedback de usuarios reales - QA ⏳
37. Documentación técnica del proyecto - Documentación ⏳
38. Cierre del proyecto y planificación futura - Gestión ⏳

**Leyenda:**  
✅ Hecho  
⏳ Pendiente  
