from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CuentoViewSet

router = DefaultRouter()
router.register(r'', CuentoViewSet, basename='cuento')

urlpatterns = [
    path('', include(router.urls)),
]
