export default function JuegosPage() {
  return <div>Página de Juegos</div>;
}
