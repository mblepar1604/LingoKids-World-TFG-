export default function CuentosPage() {
  return <div>Página de Cuentos</div>;
}
