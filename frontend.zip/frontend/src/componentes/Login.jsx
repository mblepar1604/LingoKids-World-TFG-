import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await axios.post("/api/token/", {
        username,
        password,
      });

      const { access_token, refresh_token, username: userName, es_padre, es_infantil } = response.data;

      // Guardar tokens y datos de usuario en localStorage
      localStorage.setItem("token", access_token);
      localStorage.setItem("refreshToken", refresh_token);
      localStorage.setItem(
        "user",
        JSON.stringify({
          username: userName,
          es_padre,
          es_infantil,
          token: access_token,
        })
      );

      // Redirigir al dashboard
      navigate("/");
    } catch (err) {
      setError("Credenciales incorrectas o error de servidor.");
    }
  };

  function renderForm() {
    return (
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-blue-700 text-center">Iniciar Sesión</h2>

        {error && <p className="text-red-500 mb-4 text-center">{error}</p>}

        <div className="mb-4">
          <label className="block mb-1 font-medium">Usuario:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full border rounded px-3 py-2"
            required
          />
        </div>

        <div className="mb-6">
          <label className="block mb-1 font-medium">Contraseña:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border rounded px-3 py-2"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Entrar
        </button>
      </form>
    );
  }

  function renderRegistroLink() {
    return (
      <p className="mt-4 text-center">
        ¿No tienes cuenta?{" "}
        <a href="/registro" className="text-blue-600 underline">
          Regístrate aquí
        </a>
      </p>
    );
  }

  return (
    <div className="flex justify-center items-center min-h-screen bg-blue-50">
      {renderForm()}
      {renderRegistroLink()}
    </div>
  );
}