export default function ProgresoPage() {
  return <div>Página de Progreso y Logros</div>;
}
