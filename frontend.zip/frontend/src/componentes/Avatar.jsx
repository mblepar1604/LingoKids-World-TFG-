export default function AvatarPage() {
  return <div>Página de Avatar</div>;
}
