import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Registro = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    es_padre: false,
    es_infantil: false,
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = e => {
    const { name, value, type, checked } = e.target;
    setFormData({ ...formData, [name]: type === "checkbox" ? checked : value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');

    try {
      await axios.post('/api/users/registro/', formData);
      navigate('/login');
    } catch (err) {
      setError('Error al registrar usuario');
      console.error(err);
    }
  };

  function renderForm() {
    return (
      <form onSubmit={handleSubmit}>
        <input
          name="username"
          placeholder="Nombre de usuario"
          value={formData.username}
          onChange={handleChange}
          required
        />
        <input
          name="email"
          type="email"
          placeholder="Correo electrónico"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <input
          name="password"
          type="password"
          placeholder="Contraseña"
          value={formData.password}
          onChange={handleChange}
          required
        />
        <label>
          <input
            type="checkbox"
            name="es_padre"
            checked={formData.es_padre}
            onChange={handleChange}
          />
          Padre
        </label>
        <label>
          <input
            type="checkbox"
            name="es_infantil"
            checked={formData.es_infantil}
            onChange={handleChange}
          />
          Infantil
        </label>
        <button type="submit">Registrarse</button>
      </form>
    );
  }

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Registro</h2>
      {renderForm()}
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};

export default Registro;