import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from '../pages/Home';
import Login from '../pages/Login';
import Registro from '../pages/Registro';
import Juegos from '../pages/Juegos';
import Cuentos from '../pages/Cuentos';
import ConfiguracionParental from '../pages/ConfiguracionParental';
import NotFound from '../pages/NotFound';
import PrivateRoute from './PrivateRoute';

const AppRouter = () => {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/registro" element={<Registro />} />

        {/* Rutas privadas */}
        <Route element={<PrivateRoute user={user} />}>
          <Route path="/" element={<Home />} />
          <Route path="/juegos" element={<Juegos />} />
          <Route path="/cuentos" element={<Cuentos />} />
        </Route>

        {/* Rutas exclusivas para padre */}
        <Route element={<PrivateRoute user={user} role="padre" />}>
          <Route path="/configuracion" element={<ConfiguracionParental />} />
        </Route>

        {/* Ruta 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
};

export default AppRouter;
